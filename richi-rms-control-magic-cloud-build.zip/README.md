# RICHI RMS CONTROL MAGIC

Paquete completo de la app Android nativa y del workflow de compilación en GitHub Actions.

## Compilar en GitHub Actions

1. Extrae este ZIP en un repositorio de GitHub conservando las carpetas `.github` y `android` en la raíz.
2. Sube los archivos al repositorio. El workflow también se puede iniciar manualmente desde **Actions > Android debug APK > Run workflow**.
3. Abre la ejecución terminada y descarga el artefacto `richi-rms-control-magic-debug-apk`.
4. El artefacto incluye `app-debug.apk` y se conserva durante 14 días.

El workflow instala JDK 17, Android SDK Platform 35 y Build Tools 35.0.0, y compila con el Gradle Wrapper 8.13 del proyecto.

## Compilar localmente

Abre `android/richi-rms-control-magic` en Android Studio, instala Android SDK Platform 35 y Build Tools 35.0.0 y ejecuta **Build > Build Bundle(s) / APK(s) > Build APK(s)**. También puedes ejecutar `./gradlew :app:assembleDebug` desde esa carpeta.

APK local: `android/richi-rms-control-magic/app/build/outputs/apk/debug/app-debug.apk`.

El APK de depuración sirve para pruebas y no es un paquete firmado para publicar en Google Play. Para probar BLE, instala el APK en un teléfono Android físico compatible con BLE; GitHub Actions solo compila, no tiene acceso a un teléfono.
