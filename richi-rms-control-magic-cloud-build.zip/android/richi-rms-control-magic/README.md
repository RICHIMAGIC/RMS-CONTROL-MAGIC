# RICHI RMS CONTROL MAGIC

Aplicación Android nativa en Kotlin para descubrir dispositivos Bluetooth Low Energy (BLE), seleccionar uno y guardar un dispositivo localmente.

## Requisitos

- Android Studio con JDK 17
- Android SDK Platform 35 o superior
- Un teléfono Android con Bluetooth LE para probar el escaneo

## Abrir y ejecutar

1. Abre esta carpeta en Android Studio.
2. En **Tools > SDK Manager**, instala Android SDK Platform 35 y Android SDK Build-Tools 35 si Android Studio lo solicita.
3. En **Settings > Build, Execution, Deployment > Build Tools > Gradle**, selecciona JDK 17 como **Gradle JDK**.
4. Sincroniza Gradle y ejecuta la aplicación en un teléfono Android. El emulador puede compilar la app, pero normalmente no ofrece un escáner BLE funcional.
5. Pulsa **Iniciar radar** y concede los permisos solicitados.

## Generar un APK instalable

En Android Studio, selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**. El APK de depuración instalable se genera en `app/build/outputs/apk/debug/app-debug.apk`. La carpeta `local.properties` es específica de cada equipo y está excluida del control de versiones; Android Studio la crea al detectar el SDK local.

## Compilación en GitHub Actions

El workflow `.github/workflows/android-debug-apk.yml` compila el APK en un runner de GitHub con JDK 17, Gradle 8.13, Android SDK Platform 35 y Build Tools 35.0.0. Se ejecuta manualmente desde la pestaña **Actions** o cuando hay cambios en este proyecto.

Para usarlo, sube el repositorio a GitHub manteniendo la carpeta `android/richi-rms-control-magic`, abre **Actions**, ejecuta **Android debug APK** si no se inició automáticamente y descarga el artefacto `richi-rms-control-magic-debug-apk` de la ejecución correcta. El artefacto contiene `app-debug.apk` y se conserva durante 14 días.

El APK es de depuración y se puede instalar para pruebas; no es una versión firmada para publicar en Google Play.

## Funciones

- Iniciar y detener un escaneo BLE de hasta 30 segundos.
- Mostrar dispositivos encontrados, nombre disponible, dirección y nivel de señal.
- Seleccionar un dispositivo y guardar o quitar el guardado.
- Conservar el dispositivo guardado en preferencias privadas locales, sin cuenta ni sincronización.
- Mostrar estados y errores de permisos, Bluetooth, ubicación heredada y escaneo.

La aplicación descubre anuncios BLE; no se conecta a dispositivos ni envía comandos. En Android 6–11 se requiere permiso de ubicación y que el servicio de ubicación esté activo para escanear BLE. La app no lee ni almacena coordenadas.
