package com.rms.controlmagic

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

private data class BleEntry(
    val address: String,
    val name: String,
    val rssi: Int
)

class MainActivity : Activity() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val discoveredDevices = linkedMapOf<String, BleEntry>()
    private val preferences by lazy {
        getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
    }

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var scanner: BluetoothLeScanner? = null
    private var scanning = false
    private var renderScheduled = false
    private var selectedAddress: String? = null
    private var selectedName: String? = null
    private var savedAddress: String? = null
    private var savedName: String? = null

    private lateinit var scanButton: Button
    private lateinit var statusTitle: TextView
    private lateinit var statusDetail: TextView
    private lateinit var permissionSettingsButton: Button
    private lateinit var deviceCount: TextView
    private lateinit var emptyDevices: TextView
    private lateinit var noSelectionView: TextView
    private lateinit var noSavedDeviceView: TextView
    private lateinit var devicesContainer: LinearLayout
    private lateinit var selectedCard: LinearLayout
    private lateinit var selectedNameView: TextView
    private lateinit var selectedAddressView: TextView
    private lateinit var saveSelectedButton: Button
    private lateinit var savedCard: LinearLayout
    private lateinit var savedNameView: TextView
    private lateinit var savedAddressView: TextView
    private lateinit var selectSavedButton: Button
    private lateinit var removeSavedButton: Button

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    private val scanTimeout = Runnable {
        stopRadar()
        setStatus(
            "Búsqueda finalizada",
            "Se detuvo el escaneo automático después de 30 segundos."
        )
    }

    private val refreshDevices = Runnable {
        renderScheduled = false
        renderDeviceList()
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            mainHandler.post {
                if (!scanning || isFinishing) return@post

                try {
                    val device = result.device
                    val address = device.address
                    val name = result.scanRecord?.deviceName
                        ?: device.name
                        ?: "Dispositivo BLE sin nombre"

                    discoveredDevices[address] = BleEntry(
                        address = address,
                        name = name,
                        rssi = result.rssi
                    )
                    scheduleDeviceRender()
                } catch (_: SecurityException) {
                    stopRadar()
                    setStatus(
                        "Permiso Bluetooth requerido",
                        "Android revocó el permiso de acceso. Autorízalo para continuar."
                    )
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            mainHandler.post {
                scanning = false
                mainHandler.removeCallbacks(scanTimeout)
                renderScanButton()
                renderDeviceList()
                setStatus("No se pudo completar el escaneo", scanFailureMessage(errorCode))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = COLOR_BACKGROUND
        window.navigationBarColor = COLOR_BACKGROUND

        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter

        savedAddress = preferences.getString(KEY_DEVICE_ADDRESS, null)
        savedName = preferences.getString(KEY_DEVICE_NAME, null)
        if (savedAddress != null) {
            selectedAddress = savedAddress
            selectedName = savedName
        }

        buildInterface()
        renderSavedDevice()
        renderSelection()
        renderDeviceList()

        if (bluetoothAdapter == null) {
            setStatus(
                "Bluetooth no disponible",
                "Este dispositivo no incluye un adaptador Bluetooth compatible."
            )
        }
    }

    private fun buildInterface() {
        val scrollView = ScrollView(this).apply {
            fillViewport = true
            setBackgroundColor(COLOR_BACKGROUND)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
        }

        scrollView.addView(
            content,
            ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        setContentView(scrollView)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            scrollView.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
        }

        content.addView(
            text(
                "RICHI RMS STUDIO",
                12f,
                COLOR_ACCENT,
                Typeface.BOLD
            ).apply {
                letterSpacing = 0.18f
            }
        )
        addGap(content, 8)
        content.addView(
            text("CONTROL MAGIC", 31f, COLOR_TEXT, Typeface.BOLD)
        )
        addGap(content, 4)
        content.addView(
            text(
                "Centro de dispositivos Bluetooth LE",
                15f,
                COLOR_MUTED
            )
        )
        addGap(content, 22)

        val statusCard = card()
        statusTitle = text("SISTEMA PREPARADO", 13f, COLOR_ACCENT, Typeface.BOLD)
        statusDetail = text(
            "El radar busca anuncios BLE cercanos. No se conecta ni envía comandos.",
            14f,
            COLOR_TEXT
        )
        statusCard.addView(statusTitle)
        addGap(statusCard, 7)
        statusCard.addView(statusDetail)
        content.addView(statusCard, fullWidth())
        addGap(content, 14)

        scanButton = actionButton("INICIAR RADAR", primary = true) {
            onRadarPressed()
        }
        content.addView(scanButton, fullWidth())

        permissionSettingsButton = actionButton("ABRIR AJUSTES DE LA APP") {
            openAppSettings()
        }.apply {
            visibility = View.GONE
        }
        addGap(content, 8)
        content.addView(permissionSettingsButton, fullWidth())
        addGap(content, 24)

        content.addView(sectionTitle("DISPOSITIVO GUARDADO"))
        addGap(content, 10)

        savedCard = card().apply {
            visibility = View.GONE
        }
        savedNameView = text("Sin dispositivo guardado", 16f, COLOR_TEXT, Typeface.BOLD)
        savedAddressView = text("", 12f, COLOR_MUTED)
        savedCard.addView(savedNameView)
        addGap(savedCard, 5)
        savedCard.addView(savedAddressView)
        addGap(savedCard, 12)

        val savedActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        selectSavedButton = actionButton("SELECCIONAR") {
            selectSavedDevice()
        }
        removeSavedButton = actionButton("ELIMINAR") {
            removeSavedDevice()
        }
        savedActions.addView(
            selectSavedButton,
            LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginEnd = dp(8)
            }
        )
        savedActions.addView(
            removeSavedButton,
            LinearLayout.LayoutParams(0, dp(48), 1f)
        )
        savedCard.addView(savedActions)
        content.addView(savedCard, fullWidth())

        noSavedDeviceView = text(
            "Todavía no hay dispositivos guardados.",
            14f,
            COLOR_MUTED
        )
        content.addView(noSavedDeviceView)
        addGap(content, 22)

        content.addView(sectionTitle("SELECCIÓN ACTUAL"))
        addGap(content, 10)

        selectedCard = card().apply {
            visibility = View.GONE
        }
        selectedNameView = text("", 16f, COLOR_TEXT, Typeface.BOLD)
        selectedAddressView = text("", 12f, COLOR_MUTED)
        selectedCard.addView(selectedNameView)
        addGap(selectedCard, 5)
        selectedCard.addView(selectedAddressView)
        addGap(selectedCard, 12)
        saveSelectedButton = actionButton("GUARDAR DISPOSITIVO", primary = true) {
            toggleSavedDevice()
        }
        selectedCard.addView(saveSelectedButton, fullWidth())
        content.addView(selectedCard, fullWidth())

        noSelectionView = text(
            "Selecciona un dispositivo de la lista para guardarlo.",
            14f,
            COLOR_MUTED
        )
        content.addView(noSelectionView)
        addGap(content, 22)

        val deviceHeading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        deviceHeading.addView(
            sectionTitle("DISPOSITIVOS CERCANOS"),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        deviceCount = text("0", 13f, COLOR_ACCENT, Typeface.BOLD).apply {
            gravity = Gravity.CENTER
            background = roundedBackground(COLOR_CARD_ALT, 20f)
            setPadding(dp(12), dp(7), dp(12), dp(7))
        }
        deviceHeading.addView(deviceCount)
        content.addView(deviceHeading, fullWidth())
        addGap(content, 10)

        emptyDevices = text(
            "Pulsa Iniciar radar para buscar dispositivos BLE.",
            14f,
            COLOR_MUTED
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(24), dp(20), dp(24))
            background = roundedBackground(COLOR_CARD, 18f)
        }
        content.addView(emptyDevices, fullWidth())

        devicesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(devicesContainer, fullWidth())

        addGap(content, 22)
        content.addView(
            text(
                "ESCANEO LOCAL  •  SIN CUENTA  •  SIN COMANDOS REMOTOS",
                10f,
                COLOR_MUTED,
                Typeface.BOLD
            ).apply {
                gravity = Gravity.CENTER
                letterSpacing = 0.06f
            },
            fullWidth()
        )
    }

    private fun onRadarPressed() {
        if (scanning) {
            stopRadar()
            setStatus("Radar detenido", "Puedes iniciar una nueva búsqueda cuando quieras.")
            return
        }

        val missingPermissions = missingPermissions()
        if (missingPermissions.isNotEmpty()) {
            permissionSettingsButton.visibility = View.GONE
            requestPermissions(missingPermissions, REQUEST_PERMISSIONS)
            setStatus(
                "Permiso requerido",
                "Autoriza los permisos de Bluetooth para buscar dispositivos cercanos."
            )
            return
        }

        val adapter = bluetoothAdapter
        if (adapter == null) {
            setStatus(
                "Bluetooth no disponible",
                "Este dispositivo no incluye un adaptador Bluetooth compatible."
            )
            return
        }

        try {
            if (!adapter.isEnabled) {
                startActivityForResult(
                    Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),
                    REQUEST_ENABLE_BLUETOOTH
                )
                setStatus(
                    "Bluetooth está apagado",
                    "Actívalo en la solicitud del sistema para comenzar el escaneo."
                )
                return
            }
        } catch (_: SecurityException) {
            setStatus(
                "Permiso Bluetooth requerido",
                "Autoriza el acceso a Bluetooth en los ajustes de la aplicación."
            )
            return
        } catch (_: Exception) {
            setStatus("No se pudo comprobar Bluetooth", "Intenta activar Bluetooth desde Ajustes.")
            return
        }

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R && !isLocationServiceEnabled()) {
            setStatus(
                "Activa la ubicación del sistema",
                "Android 6–11 la requiere para escanear BLE. La app no recopila coordenadas."
            )
            return
        }

        beginScan(adapter)
    }

    private fun beginScan(adapter: BluetoothAdapter) {
        try {
            val activeScanner = adapter.bluetoothLeScanner
            if (activeScanner == null) {
                setStatus(
                    "Escáner BLE no disponible",
                    "Comprueba que Bluetooth esté activo y que el dispositivo admita BLE."
                )
                return
            }

            scanner = activeScanner
            discoveredDevices.clear()
            renderDeviceList()
            activeScanner.startScan(scanCallback)
            scanning = true
            mainHandler.removeCallbacks(scanTimeout)
            mainHandler.postDelayed(scanTimeout, SCAN_DURATION_MS)
            renderScanButton()
            renderDeviceList()
            setStatus(
                "Radar activo",
                "Buscando dispositivos cercanos. El escaneo se detiene automáticamente en 30 segundos."
            )
        } catch (_: SecurityException) {
            scanning = false
            renderScanButton()
            setStatus(
                "Permiso Bluetooth requerido",
                "Android no autorizó el escaneo. Revisa los permisos de la aplicación."
            )
        } catch (_: IllegalStateException) {
            scanning = false
            renderScanButton()
            setStatus(
                "No se pudo iniciar el radar",
                "Bluetooth cambió de estado. Comprueba que siga activado e inténtalo de nuevo."
            )
        } catch (_: Exception) {
            scanning = false
            renderScanButton()
            setStatus(
                "Error de escaneo",
                "No fue posible iniciar el escáner Bluetooth LE."
            )
        }
    }

    private fun stopRadar() {
        mainHandler.removeCallbacks(scanTimeout)
        mainHandler.removeCallbacks(refreshDevices)
        renderScheduled = false

        if (scanning) {
            try {
                scanner?.stopScan(scanCallback)
            } catch (_: SecurityException) {
                // El permiso pudo revocarse durante el escaneo.
            } catch (_: IllegalStateException) {
                // El sistema pudo detener el escaneo antes que la actividad.
            } catch (_: Exception) {
                // Mantiene la interfaz utilizable si el adaptador ya se apagó.
            }
        }

        scanning = false
        renderScanButton()
        renderDeviceList()
    }

    private fun missingPermissions(): Array<String> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return emptyArray()
        }

        return requiredPermissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()
    }

    private fun isLocationServiceEnabled(): Boolean {
        return try {
            val locationManager =
                getSystemService(Context.LOCATION_SERVICE) as LocationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                locationManager.isLocationEnabled
            } else {
                locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                    locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun scheduleDeviceRender() {
        if (!renderScheduled) {
            renderScheduled = true
            mainHandler.postDelayed(refreshDevices, DEVICE_RENDER_DELAY_MS)
        }
    }

    private fun renderDeviceList() {
        if (!::devicesContainer.isInitialized) return

        devicesContainer.removeAllViews()
        val sortedDevices = discoveredDevices.values.sortedByDescending { it.rssi }

        deviceCount.text = sortedDevices.size.toString()
        emptyDevices.visibility = if (sortedDevices.isEmpty()) View.VISIBLE else View.GONE
        if (sortedDevices.isEmpty()) {
            emptyDevices.text = if (scanning) {
                "Buscando transmisiones BLE cercanas…"
            } else {
                "Pulsa Iniciar radar para buscar dispositivos BLE."
            }
            return
        }

        sortedDevices.forEach { entry ->
            val isSelected = entry.address == selectedAddress
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = roundedBackground(
                    if (isSelected) COLOR_SELECTED else COLOR_CARD,
                    16f,
                    if (isSelected) COLOR_ACCENT else COLOR_BORDER
                )
                isClickable = true
                isFocusable = true
                contentDescription = "${entry.name}, ${entry.rssi} dBm, seleccionar dispositivo"
                setOnClickListener {
                    selectedAddress = entry.address
                    selectedName = entry.name
                    renderSelection()
                    renderDeviceList()
                    setStatus(
                        "Dispositivo seleccionado",
                        "Puedes guardarlo localmente desde la tarjeta de selección."
                    )
                }
            }

            val topLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            topLine.addView(
                text(entry.name, 15f, COLOR_TEXT, Typeface.BOLD),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            topLine.addView(
                text(signalLabel(entry.rssi), 11f, signalColor(entry.rssi), Typeface.BOLD)
            )
            row.addView(topLine)
            addGap(row, 5)
            row.addView(text(entry.address, 12f, COLOR_MUTED))
            addGap(row, 5)
            row.addView(
                text("${entry.rssi} dBm  •  ${signalDescription(entry.rssi)}", 12f, COLOR_ACCENT)
            )

            devicesContainer.addView(
                row,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(9)
                }
            )
        }
    }

    private fun renderScanButton() {
        if (!::scanButton.isInitialized) return
        scanButton.text = if (scanning) "DETENER RADAR" else "INICIAR RADAR"
        scanButton.background = roundedBackground(
            if (scanning) COLOR_STOP else COLOR_ACCENT,
            16f
        )
        scanButton.setTextColor(if (scanning) COLOR_TEXT else COLOR_INK)
    }

    private fun renderSelection() {
        if (!::selectedCard.isInitialized) return

        val address = selectedAddress
        if (address.isNullOrBlank()) {
            selectedCard.visibility = View.GONE
            noSelectionView.visibility = View.VISIBLE
            return
        }

        val name = selectedName ?: "Dispositivo BLE"
        selectedCard.visibility = View.VISIBLE
        noSelectionView.visibility = View.GONE
        selectedNameView.text = name
        selectedAddressView.text = address

        val alreadySaved = address == savedAddress
        saveSelectedButton.text = if (alreadySaved) {
            "QUITAR DE GUARDADOS"
        } else {
            "GUARDAR DISPOSITIVO"
        }
        saveSelectedButton.background = roundedBackground(
            if (alreadySaved) COLOR_CARD_ALT else COLOR_ACCENT,
            14f
        )
        saveSelectedButton.setTextColor(if (alreadySaved) COLOR_TEXT else COLOR_INK)
    }

    private fun renderSavedDevice() {
        if (!::savedCard.isInitialized) return

        val address = savedAddress
        if (address.isNullOrBlank()) {
            savedCard.visibility = View.GONE
            noSavedDeviceView.visibility = View.VISIBLE
            return
        }

        savedCard.visibility = View.VISIBLE
        noSavedDeviceView.visibility = View.GONE
        savedNameView.text = savedName ?: "Dispositivo BLE"
        savedAddressView.text = address
    }

    private fun toggleSavedDevice() {
        val address = selectedAddress
        if (address.isNullOrBlank()) {
            setStatus(
                "Selecciona un dispositivo",
                "Elige un dispositivo de la lista antes de guardarlo."
            )
            return
        }

        if (address == savedAddress) {
            removeSavedDevice()
            return
        }

        val name = selectedName ?: "Dispositivo BLE"
        preferences.edit()
            .putString(KEY_DEVICE_ADDRESS, address)
            .putString(KEY_DEVICE_NAME, name)
            .apply()

        savedAddress = address
        savedName = name
        renderSavedDevice()
        renderSelection()
        setStatus("Dispositivo guardado", "$name se guardó solo en este dispositivo.")
    }

    private fun removeSavedDevice() {
        preferences.edit()
            .remove(KEY_DEVICE_ADDRESS)
            .remove(KEY_DEVICE_NAME)
            .apply()

        savedAddress = null
        savedName = null
        renderSavedDevice()
        renderSelection()
        setStatus("Guardado eliminado", "El dispositivo local se quitó de la lista guardada.")
    }

    private fun selectSavedDevice() {
        val address = savedAddress ?: return
        selectedAddress = address
        selectedName = savedName ?: "Dispositivo BLE"
        renderSelection()
        renderDeviceList()
        setStatus(
            "Dispositivo guardado seleccionado",
            "El registro está guardado localmente; no se ha iniciado una conexión."
        )
    }

    private fun setStatus(title: String, detail: String, isError: Boolean = false) {
        if (!::statusTitle.isInitialized || isFinishing) return
        statusTitle.text = title.uppercase()
        statusTitle.setTextColor(if (isError) COLOR_ERROR else COLOR_ACCENT)
        statusDetail.text = detail
    }

    private fun openAppSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        } catch (_: Exception) {
            setStatus(
                "No se pudieron abrir los ajustes",
                "Abre Ajustes del sistema y busca los permisos de esta aplicación.",
                isError = true
            )
        }
    }

    @Deprecated("Uses the platform activity result callback for Bluetooth activation.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_ENABLE_BLUETOOTH) return

        if (resultCode == RESULT_OK) {
            val adapter = bluetoothAdapter
            if (adapter != null) {
                beginScan(adapter)
            }
        } else {
            setStatus(
                "Bluetooth sigue apagado",
                "Activa Bluetooth para poder buscar dispositivos BLE."
            )
        }
    }

    @Deprecated("Uses the platform permission result callback.")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_PERMISSIONS) return

        val granted = grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }

        if (granted) {
            permissionSettingsButton.visibility = View.GONE
            onRadarPressed()
            return
        }

        val permanentlyDenied = permissions.indices.any { index ->
            grantResults.getOrNull(index) != PackageManager.PERMISSION_GRANTED &&
                !shouldShowRequestPermissionRationale(permissions[index])
        }
        permissionSettingsButton.visibility =
            if (permanentlyDenied) View.VISIBLE else View.GONE

        setStatus(
            "Permiso no concedido",
            if (permanentlyDenied) {
                "Autoriza el permiso de Bluetooth desde los ajustes de la aplicación."
            } else {
                "El radar necesita los permisos de Bluetooth para buscar dispositivos."
            },
            isError = true
        )
    }

    override fun onDestroy() {
        stopRadar()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun scanFailureMessage(errorCode: Int): String = when (errorCode) {
        ScanCallback.SCAN_FAILED_ALREADY_STARTED ->
            "Ya hay un escaneo activo. Detén el radar e inténtalo otra vez."
        ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED ->
            "Android no pudo registrar la aplicación para escanear."
        ScanCallback.SCAN_FAILED_FEATURE_UNSUPPORTED ->
            "El adaptador Bluetooth no admite esta función de escaneo."
        ScanCallback.SCAN_FAILED_INTERNAL_ERROR ->
            "Bluetooth informó de un error interno. Inténtalo de nuevo."
        ScanCallback.SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES ->
            "El adaptador no tiene recursos disponibles para otro escaneo."
        ScanCallback.SCAN_FAILED_SCANNING_TOO_FREQUENTLY ->
            "Android limitó los escaneos repetidos. Espera unos segundos."
        else -> "Código de error: $errorCode."
    }

    private fun signalLabel(rssi: Int): String = when {
        rssi >= -55 -> "FUERTE"
        rssi >= -75 -> "MEDIA"
        else -> "DÉBIL"
    }

    private fun signalDescription(rssi: Int): String = when {
        rssi >= -55 -> "señal fuerte"
        rssi >= -75 -> "señal media"
        else -> "señal débil"
    }

    private fun signalColor(rssi: Int): Int = when {
        rssi >= -55 -> COLOR_ACCENT
        rssi >= -75 -> COLOR_SIGNAL_MEDIUM
        else -> COLOR_MUTED
    }

    private fun sectionTitle(value: String): TextView =
        text(value, 12f, COLOR_MUTED, Typeface.BOLD).apply {
            letterSpacing = 0.08f
        }

    private fun text(
        value: String,
        size: Float,
        color: Int,
        style: Int = Typeface.NORMAL
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif", style)
        includeFontPadding = true
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = roundedBackground(COLOR_CARD, 18f, COLOR_BORDER)
    }

    private fun actionButton(
        label: String,
        primary: Boolean = false,
        action: () -> Unit
    ): Button = Button(this).apply {
        text = label
        setAllCaps(false)
        textSize = 14f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER
        minHeight = dp(48)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setTextColor(if (primary) COLOR_INK else COLOR_TEXT)
        background = roundedBackground(
            if (primary) COLOR_ACCENT else COLOR_CARD_ALT,
            14f,
            if (primary) COLOR_ACCENT else COLOR_BORDER
        )
        backgroundTintList = null
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun roundedBackground(
        fillColor: Int,
        radiusDp: Float,
        strokeColor: Int? = null
    ): GradientDrawable = GradientDrawable().apply {
        setColor(fillColor)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        if (strokeColor != null) {
            setStroke(dp(1), strokeColor)
        }
    }

    private fun addGap(parent: LinearLayout, heightDp: Int) {
        parent.addView(
            View(this),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(heightDp)
            )
        )
    }

    private fun fullWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val PREFERENCES_NAME = "rms_magic_preferences"
        private const val KEY_DEVICE_ADDRESS = "saved_device_address"
        private const val KEY_DEVICE_NAME = "saved_device_name"
        private const val REQUEST_PERMISSIONS = 100
        private const val REQUEST_ENABLE_BLUETOOTH = 101
        private const val SCAN_DURATION_MS = 30_000L
        private const val DEVICE_RENDER_DELAY_MS = 300L
        private val COLOR_BACKGROUND = Color.rgb(10, 16, 32)
        private val COLOR_CARD = Color.rgb(18, 27, 45)
        private val COLOR_CARD_ALT = Color.rgb(29, 40, 61)
        private val COLOR_SELECTED = Color.rgb(31, 39, 54)
        private val COLOR_BORDER = Color.rgb(48, 61, 84)
        private val COLOR_ACCENT = Color.rgb(221, 187, 104)
        private val COLOR_TEXT = Color.rgb(245, 247, 250)
        private val COLOR_MUTED = Color.rgb(155, 168, 188)
        private val COLOR_INK = Color.rgb(19, 22, 29)
        private val COLOR_STOP = Color.rgb(151, 57, 61)
        private val COLOR_ERROR = Color.rgb(255, 130, 130)
        private val COLOR_SIGNAL_MEDIUM = Color.rgb(245, 183, 84)
    }
}
